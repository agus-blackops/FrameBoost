# Poder Supremo (Minecraft Bedrock addon)

Instalar: abre `dist/PoderSupremo.mcaddon` en Minecraft Bedrock (o descomprime el `.zip` y copia `BP` y `RP` a `development_behavior_packs` / `development_resource_packs`).
Activa ambos packs en el mundo (no hace falta ningún experimento). Si algún objeto no aparece, prueba activando "Holiday Creator Features" en Experimentos.

Kit completo: `/scriptevent fb:kit`

| Objeto | Qué hace |
|---|---|
| Mazo de Minecraft (el normal) | Al sostenerlo tiene aim assist; **agachado o cayendo = aimbot total** (hasta 20 bloques al caer, para el smash). Daño y smash son los del juego |
| Espada del Titán | +34 de daño extra |
| Hacha de Tormenta | +22 de daño y rayo |
| Corazón Divino (click derecho) | Regeneración X, Fuerza X, Resistencia, Absorción, Velocidad por 5 min |
| Núcleo Inmortal (en inventario) | Con ≤3 corazones te cura al máximo y da resistencia (cooldown 30 s) |
| Orbe de Restauración (clic derecho) | Devuelve los objetos y mobs que desaparecieron sin morir, sin ser recogidos y sin expirar |
| Antidote (golpear) | Un solo uso: si golpeas a `FaultierLocket0` le quita toda la armadura y todos los efectos. Contra otros jugadores no hace nada y no se gasta |

**Antidote — escudo contra el Golpe Supremo:** con el Antidote en tu inventario, si `FaultierLocket0` te golpea (el "Golpe Supremo") el addon restaura al instante tus efectos y objetos del addon durante 5 s, y llegan los **5 aliados** por 2 min (espera 3 min): Jefe Final, Warden Final (vida infinita; destruye toda la armadura de quien golpea), Clawd, La Convergencia y el Logo de ChatGPT. Prueba: `/scriptevent fb:aliados`. Ojo: golpear a FaultierLocket0 con el Antidote lo gasta.

**Jefe Final:** cuando `DiamondHalo9031` queda con 3 corazones o menos aparece un Golem de Hierro gigante y muy potenciado ("Jefe Final") que lo protege durante 90 s: golpea a los monstruos cercanos y a quien lo haya herido hace poco, y le da resistencia y regeneración. Reaparece tras 5 min. Prueba rápida: `/scriptevent fb:boss`. Ajustes en `DUENO` y `BOSS` de `main.js`.

**Orbe — límites:** no puede saber qué hizo el mod de tu hermano, así que detecta "desapareció cerca de un jugador sin causa normal". Solo ve lo que ocurre en un radio de 48 bloques de algún jugador, con el addon ya activo; el registro se pierde al cerrar el mundo; los mobs vuelven sin datos extra (domesticación, armadura, vida) y los bloques borrados no se restauran. Un objeto borrado a menos de 5 bloques de un jugador se confunde con "recogido".

**El elegido:** `FaultierLocket0` está en la lista `NO_ELEGIDOS` de `BP/scripts/main.js`: los objetos no le obedecen y ve "no es el elegido". Para agregar más, edita la lista o usa `/tag <jugador> add fb_no_elegido`.

Regenerar texturas y zips: `python3 build.py`
